--
-- PostgreSQL database dump
--

\restrict eDPdhCP2Wu0g1yiy1xhLW8DJQjnYa6s2AGHqnbwm84UdZ3O21tT7pf2sxbtfHid

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: scheduler
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO scheduler;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: scheduler
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_meta; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.app_meta (
    key text NOT NULL,
    value text
);


ALTER TABLE public.app_meta OWNER TO scheduler;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.bookings (
    id text NOT NULL,
    specialist_id text NOT NULL,
    client_id text NOT NULL,
    session_type_id text NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    client_name text NOT NULL,
    client_message text,
    status text DEFAULT 'pending'::text,
    cancel_reason text,
    cancelled_by text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    reminder_sent integer DEFAULT 0,
    duration_minutes integer DEFAULT 60,
    created_by text,
    recurring_schedule_id text,
    replaces_booking_id text,
    telegram_notification_chat_id bigint,
    telegram_notification_msg_id integer,
    client_notification_chat_id bigint,
    client_notification_msg_id integer,
    client_batch_id text,
    CONSTRAINT bookings_cancelled_by_specialist_check CHECK (((cancelled_by = ANY (ARRAY['client'::text, 'specialist'::text])) OR (cancelled_by IS NULL))),
    CONSTRAINT bookings_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'confirmed'::text, 'rejected'::text, 'cancelled'::text, 'completed'::text, 'cancel_requested'::text, 'reschedule_pending'::text])))
);


ALTER TABLE public.bookings OWNER TO scheduler;

--
-- Name: client_batches; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.client_batches (
    id text NOT NULL,
    client_id text NOT NULL,
    specialist_id text NOT NULL,
    service_id text NOT NULL,
    total_sessions integer NOT NULL,
    remaining_sessions integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status text DEFAULT 'active'::text NOT NULL,
    CONSTRAINT client_batches_remaining_sessions_check CHECK ((remaining_sessions >= 0)),
    CONSTRAINT client_batches_status_check CHECK ((status = ANY (ARRAY['active'::text, 'exhausted'::text]))),
    CONSTRAINT client_batches_total_sessions_check CHECK ((total_sessions > 1))
);


ALTER TABLE public.client_batches OWNER TO scheduler;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.clients (
    id text NOT NULL,
    telegram_user_id bigint NOT NULL,
    specialist_id text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    phone text,
    preferred_duration integer DEFAULT 60,
    notify_booking_status integer DEFAULT 1,
    notify_reminders integer DEFAULT 1,
    notify_days_off integer DEFAULT 0,
    notify_waitlist integer DEFAULT 1,
    photo_url text DEFAULT ''::text,
    notify_cancellations integer DEFAULT 1,
    is_ghost integer DEFAULT 0,
    language text DEFAULT 'ru'::text,
    display_name text DEFAULT ''::text,
    is_blocked integer DEFAULT 0,
    referred_via_code text,
    telegram_username text DEFAULT ''::text,
    photo_removed integer DEFAULT 0
);


ALTER TABLE public.clients OWNER TO scheduler;

--
-- Name: dashboard_audit_log; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.dashboard_audit_log (
    id text NOT NULL,
    actor_telegram_id bigint NOT NULL,
    method text NOT NULL,
    path text NOT NULL,
    action text NOT NULL,
    specialist_id text,
    status_code integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dashboard_audit_log OWNER TO scheduler;

--
-- Name: days_off; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.days_off (
    id text NOT NULL,
    specialist_id text NOT NULL,
    date date NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.days_off OWNER TO scheduler;

--
-- Name: master_users; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.master_users (
    telegram_user_id bigint NOT NULL,
    language text DEFAULT 'ru'::text NOT NULL,
    first_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.master_users OWNER TO scheduler;

--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.promo_codes (
    id text NOT NULL,
    code text NOT NULL,
    discount_type text NOT NULL,
    discount_value integer NOT NULL,
    duration_days integer DEFAULT 0,
    max_redemptions integer,
    redemptions_count integer DEFAULT 0,
    valid_from timestamp with time zone,
    valid_until timestamp with time zone,
    applies_to_plan text DEFAULT ''::text,
    referral_specialist_id text DEFAULT ''::text,
    is_active integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.promo_codes OWNER TO scheduler;

--
-- Name: promo_redemptions; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.promo_redemptions (
    id text NOT NULL,
    promo_code_id text NOT NULL,
    specialist_id text NOT NULL,
    payment_id text DEFAULT ''::text,
    discount_kopecks integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.promo_redemptions OWNER TO scheduler;

--
-- Name: recurring_schedules; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.recurring_schedules (
    id text NOT NULL,
    specialist_id text NOT NULL,
    client_id text NOT NULL,
    client_name text NOT NULL,
    day_of_week integer NOT NULL,
    "time" text NOT NULL,
    duration_minutes integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    session_type_id text,
    days_of_week text,
    start_date text,
    end_date text,
    day_times text,
    CONSTRAINT recurring_schedules_created_by_specialist_check CHECK ((created_by = ANY (ARRAY['client'::text, 'specialist'::text]))),
    CONSTRAINT recurring_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT recurring_schedules_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'declined'::text, 'cancelled'::text])))
);


ALTER TABLE public.recurring_schedules OWNER TO scheduler;

--
-- Name: session_types; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.session_types (
    id text NOT NULL,
    specialist_id text NOT NULL,
    type text DEFAULT 'common'::text NOT NULL,
    name text NOT NULL,
    duration_minutes integer NOT NULL,
    price integer NOT NULL,
    currency text DEFAULT 'RUB'::text,
    is_active integer DEFAULT 1,
    image_url text DEFAULT ''::text,
    sessions_count integer,
    CONSTRAINT session_types_batch_sessions_count_check CHECK (((type <> 'batch'::text) OR (sessions_count > 1))),
    CONSTRAINT session_types_sessions_count_min_check CHECK (((sessions_count IS NULL) OR (sessions_count > 1))),
    CONSTRAINT session_types_type_common_batch_check CHECK ((type = ANY (ARRAY['common'::text, 'batch'::text])))
);


ALTER TABLE public.session_types OWNER TO scheduler;

--
-- Name: specialists; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.specialists (
    id text NOT NULL,
    telegram_user_id bigint NOT NULL,
    bot_token text NOT NULL,
    bot_username text NOT NULL,
    webhook_secret text NOT NULL,
    name text NOT NULL,
    timezone text DEFAULT 'Europe/Moscow'::text,
    cancel_cutoff_hrs integer DEFAULT 24,
    is_active integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    telegram_handle text,
    phone text,
    specialization text,
    bio text,
    photo_url text,
    bot_token_hash text,
    location_latitude double precision DEFAULT 0,
    location_longitude double precision DEFAULT 0,
    location_address text,
    available_durations text,
    notify_new_bookings integer DEFAULT 1,
    notify_cancellations integer DEFAULT 1,
    language text DEFAULT 'ru'::text,
    wallpaper text DEFAULT ''::text,
    referral_code text,
    deleted_at timestamp with time zone,
    referred_via_code text,
    first_payment_at timestamp with time zone,
    photo_removed integer DEFAULT 0,
    subscription_status text DEFAULT 'trialing'::text,
    subscription_plan text DEFAULT 'pro'::text,
    trial_ends_at timestamp with time zone,
    subscription_started_at timestamp with time zone,
    current_period_end_at timestamp with time zone,
    auto_renew integer DEFAULT 1,
    cancel_at_period_end integer DEFAULT 0,
    yookassa_payment_method_id text,
    email text,
    has_trialed integer DEFAULT 0 NOT NULL,
    consent_accepted_at timestamp without time zone,
    consent_version text DEFAULT ''::text,
    cancel_cutoff_enabled integer DEFAULT 0
);


ALTER TABLE public.specialists OWNER TO scheduler;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.subscription_payments (
    id text NOT NULL,
    specialist_id text NOT NULL,
    yookassa_payment_id text NOT NULL,
    amount_kopecks integer NOT NULL,
    currency text DEFAULT 'RUB'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    plan_code text NOT NULL,
    promo_code text DEFAULT ''::text,
    discount_kopecks integer DEFAULT 0,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    is_renewal integer DEFAULT 0,
    payment_method_id text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    paid_at timestamp with time zone,
    raw_payload text DEFAULT ''::text
);


ALTER TABLE public.subscription_payments OWNER TO scheduler;

--
-- Name: support_threads; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.support_threads (
    id text NOT NULL,
    telegram_user_id bigint NOT NULL,
    telegram_username text DEFAULT ''::text,
    display_name text DEFAULT ''::text,
    language_code text DEFAULT ''::text,
    topic_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_message_at timestamp with time zone,
    closed_at timestamp with time zone
);


ALTER TABLE public.support_threads OWNER TO scheduler;

--
-- Name: trainers; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.trainers (
    id text NOT NULL,
    telegram_user_id bigint NOT NULL,
    bot_token text NOT NULL,
    bot_username text NOT NULL,
    webhook_secret text NOT NULL,
    name text NOT NULL,
    timezone text DEFAULT 'Europe/Moscow'::text,
    cancel_cutoff_hrs integer DEFAULT 24,
    is_active integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    telegram_handle text,
    phone text,
    specialization text,
    bio text,
    photo_url text,
    bot_token_hash text,
    gym_latitude double precision DEFAULT 0,
    gym_longitude double precision DEFAULT 0,
    gym_address text,
    available_durations text,
    notify_new_bookings integer DEFAULT 1,
    notify_cancellations integer DEFAULT 1
);


ALTER TABLE public.trainers OWNER TO scheduler;

--
-- Name: waitlist; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.waitlist (
    id text NOT NULL,
    specialist_id text NOT NULL,
    client_id text NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    duration_minutes integer NOT NULL,
    client_name text NOT NULL,
    status text DEFAULT 'waiting'::text NOT NULL,
    offered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT waitlist_status_check CHECK ((status = ANY (ARRAY['waiting'::text, 'offered'::text, 'booked'::text, 'declined'::text, 'expired'::text, 'cancelled'::text])))
);


ALTER TABLE public.waitlist OWNER TO scheduler;

--
-- Name: working_hours; Type: TABLE; Schema: public; Owner: scheduler
--

CREATE TABLE public.working_hours (
    id text NOT NULL,
    specialist_id text NOT NULL,
    day_of_week integer NOT NULL,
    start_time text NOT NULL,
    end_time text NOT NULL,
    CONSTRAINT working_hours_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6)))
);


ALTER TABLE public.working_hours OWNER TO scheduler;

--
-- Data for Name: app_meta; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.app_meta (key, value) FROM stdin;
subscription_grace_applied	1
has_trialed_backfilled	1
recurring_payments_enabled	1
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.bookings (id, specialist_id, client_id, session_type_id, starts_at, ends_at, client_name, client_message, status, cancel_reason, cancelled_by, created_at, reminder_sent, duration_minutes, created_by, recurring_schedule_id, replaces_booking_id, telegram_notification_chat_id, telegram_notification_msg_id, client_notification_chat_id, client_notification_msg_id, client_batch_id) FROM stdin;
4713ae25-c718-4a19-b92f-83668d4ea6ff	609308e0-556b-41e1-8b39-6a719c0dc6e9	1be66c35-98af-4caf-a6b6-797062450099	ed0fa9c2-9eec-4f77-bc23-17057e81e9b4	2026-06-24 23:00:00+00	2026-06-25 00:00:00+00	Karlen		completed	\N	\N	2026-06-24 17:24:41.685823+00	1	60	specialist	\N	\N	\N	\N	459457399	14	\N
0663d58e-ccf5-442b-a112-ebd6d975992a	7a375784-31d4-427d-a1bf-a5007bba2c02	7ca5ec17-5955-41ad-9f24-ecff756c0c57	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-16 19:00:00+00	2026-06-16 20:00:00+00	Karlen		cancelled	\N	\N	2026-06-16 15:11:36.505535+00	0	60	specialist	\N	\N	\N	\N	459457399	647	\N
3bf14c0b-3084-45cb-968c-023522f58483	97fdb979-27db-4561-90ec-4b9deb66dfbe	ef71de5e-aa5e-4b61-a8db-5696366faabc	0ecfab49-292e-483a-bccb-3f2c1506229b	2026-02-11 12:00:00+00	2026-02-11 13:00:00+00	Мери		rejected	\N	\N	2026-02-10 11:49:19+00	0	60	\N	\N	\N	\N	\N	\N	\N	\N
cadcda64-8b7f-42e0-9048-5a65f7de05fc	609308e0-556b-41e1-8b39-6a719c0dc6e9	f5a4fd69-c8ed-420d-93e7-b1b9a27b0990	ed0fa9c2-9eec-4f77-bc23-17057e81e9b4	2026-06-24 21:00:00+00	2026-06-24 22:00:00+00	~		cancelled	\N	\N	2026-06-24 17:40:39.471989+00	0	60	specialist	\N	\N	\N	\N	873486696	19	\N
a2cdcb5a-75df-45ea-b69d-46d1a49da7e2	7a375784-31d4-427d-a1bf-a5007bba2c02	7ca5ec17-5955-41ad-9f24-ecff756c0c57	701c8d08-f532-4226-8554-ba5d493812f2	2026-07-07 10:30:00+00	2026-07-07 12:00:00+00	Karlen		cancelled	\N	\N	2026-06-29 19:04:55.845622+00	0	90	specialist	\N	\N	\N	\N	\N	\N	\N
072d0eb8-37e5-402d-8cfc-5baa0bc6fa16	7a375784-31d4-427d-a1bf-a5007bba2c02	7ca5ec17-5955-41ad-9f24-ecff756c0c57	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-29 22:00:00+00	2026-06-29 23:00:00+00	Karlen		confirmed	\N	\N	2026-06-29 18:17:11.024108+00	1	60	specialist	\N	\N	\N	\N	\N	\N	\N
54ee6324-47eb-40cb-ba62-81b6577a209e	7a375784-31d4-427d-a1bf-a5007bba2c02	7ca5ec17-5955-41ad-9f24-ecff756c0c57	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-30 13:00:00+00	2026-06-30 14:00:00+00	Karlen		confirmed	\N	\N	2026-06-29 19:04:44.989569+00	1	60	specialist	\N	\N	\N	\N	\N	\N	\N
15ce8df5-122a-4784-9b6f-e598fe6600b2	7a375784-31d4-427d-a1bf-a5007bba2c02	7ca5ec17-5955-41ad-9f24-ecff756c0c57	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-30 15:00:00+00	2026-06-30 16:00:00+00	Karlen		confirmed	\N	\N	2026-06-29 17:46:47.037452+00	1	60	specialist	\N	\N	\N	\N	\N	\N	\N
18b0a9ec-aae6-41be-900a-7eed38234af1	7a375784-31d4-427d-a1bf-a5007bba2c02	82ed251f-8eec-455f-8361-29b269564b16	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-30 16:00:00+00	2026-06-30 17:00:00+00	Viktor		confirmed	\N	\N	2026-06-29 11:48:00.939829+00	1	60	specialist	\N	\N	\N	\N	8520046459	655	\N
a736e208-3a73-40a8-8148-171f7255e194	7a375784-31d4-427d-a1bf-a5007bba2c02	7ca5ec17-5955-41ad-9f24-ecff756c0c57	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-17 13:00:00+00	2026-06-17 14:00:00+00	Karlen		reschedule_pending	\N	\N	2026-06-16 15:14:13.749822+00	0	60	specialist	\N	0663d58e-ccf5-442b-a112-ebd6d975992a	\N	\N	\N	\N	\N
aeceb256-a9f0-495e-94fa-65ef38a25928	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	2575cd13-7d31-4e8e-b6e5-dfc61f2039b6	45ab27e8-1d51-400b-b9db-10100af2bb1d	2026-02-18 09:00:00+00	2026-02-18 10:00:00+00	Maria Borsheva		confirmed	\N	\N	2026-02-15 15:49:43.804454+00	1	60	\N	\N	\N	864560981	8	\N	\N	\N
b2b0c3e0-4c25-4791-aa0f-7596f0baad74	2d8f2756-6958-4197-8b07-1238d0005781	cc612e3d-e163-475d-8ccd-839cd0a8030b	10109c9b-3ef6-4487-8207-3190e4730386	2026-06-25 12:00:00+00	2026-06-25 13:00:00+00	Иван		confirmed	\N	\N	2026-06-23 16:31:43.815439+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
be0a8134-215c-4556-aefd-e5d60bf48706	7a375784-31d4-427d-a1bf-a5007bba2c02	999a9fbc-ff57-48f9-bdf6-241bbd8dbad7	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-30 17:00:00+00	2026-06-30 18:00:00+00	Знакомый Кирилл		confirmed	\N	\N	2026-06-29 11:48:36.159637+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
1b9807fc-c6f6-44f7-a078-f8017946fef4	609308e0-556b-41e1-8b39-6a719c0dc6e9	f5a4fd69-c8ed-420d-93e7-b1b9a27b0990	ed0fa9c2-9eec-4f77-bc23-17057e81e9b4	2026-06-24 21:00:00+00	2026-06-24 22:00:00+00	~		completed	\N	\N	2026-06-24 17:41:20.866318+00	1	60	specialist	\N	\N	\N	\N	873486696	22	\N
962700f9-ce5e-4fd7-8290-9f4a5c85cf35	609308e0-556b-41e1-8b39-6a719c0dc6e9	f5a4fd69-c8ed-420d-93e7-b1b9a27b0990	a933afb8-8bd9-4754-b1d9-d4849efea2a7	2026-06-24 21:00:00+00	2026-06-24 22:00:00+00	~		cancelled	\N	\N	2026-06-24 17:34:56.77555+00	0	60	specialist	\N	\N	\N	\N	873486696	16	\N
2689f441-ea2a-4abc-a1fe-658cff334544	8dba2e99-0778-48a4-b243-ea784844fe52	bea44348-f5be-42de-ba4f-eca79f759baa	fe41b94b-9eb5-4a7c-9593-8686c35d231f	2026-04-29 11:00:00+00	2026-04-29 12:00:00+00	ate	Добрый день! Можно ли записаться на консультацию?	confirmed	\N	\N	2026-04-27 13:05:41.967293+00	1	60	\N	\N	\N	1153633029	16	\N	\N	\N
f5a50dc6-c43e-4526-b937-280512a7cf2d	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	2575cd13-7d31-4e8e-b6e5-dfc61f2039b6	45ab27e8-1d51-400b-b9db-10100af2bb1d	2026-02-16 09:00:00+00	2026-02-16 10:00:00+00	Maria Borsheva		confirmed	\N	\N	2026-02-15 15:44:52.796252+00	1	60	\N	\N	\N	864560981	5	\N	\N	\N
e0355732-6f50-4b29-b0e0-ec5039897fd1	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	2575cd13-7d31-4e8e-b6e5-dfc61f2039b6	c468d8ad-1805-478b-8ac9-be5a82d3404c	2026-02-17 09:30:00+00	2026-02-17 10:00:00+00	Maria Borsheva		confirmed	\N	\N	2026-02-15 15:47:54.807365+00	1	30	\N	\N	\N	864560981	6	\N	\N	\N
6a822199-472e-4c8a-b2e5-e0d2fe58fe58	7a375784-31d4-427d-a1bf-a5007bba2c02	000e78f2-bd69-4904-a898-68f9091ee543	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-17 11:00:00+00	2026-06-17 12:00:00+00	Виктор		cancelled	\N	\N	2026-06-16 15:14:59.884375+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
140a6a81-5659-41c4-b98b-542fe1511931	609308e0-556b-41e1-8b39-6a719c0dc6e9	c15545ca-f1e4-4887-86cb-8b5cc52f426f	a933afb8-8bd9-4754-b1d9-d4849efea2a7	2026-06-26 10:00:00+00	2026-06-26 11:00:00+00	Кара		completed	\N	\N	2026-06-24 16:37:24.345075+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
eeb4ecf6-012e-41a5-817e-a74a1a2e61a0	97fdb979-27db-4561-90ec-4b9deb66dfbe	94e2175b-303a-400d-9e27-d6dbf4cf624c	a7272b78-d2f8-4927-b84d-ee327fa43f0d	2026-02-18 12:00:00+00	2026-02-18 13:30:00+00	~	Можно мне ресницы сделать?) 	completed	\N	\N	2026-02-17 19:37:29.118829+00	1	90	\N	\N	\N	1098117089	23	\N	\N	\N
5fe2b9c1-a3b5-44f9-b10e-1a9036bc5a68	609308e0-556b-41e1-8b39-6a719c0dc6e9	341d8ef6-c9ec-455c-8f12-6b23c67a0253	a933afb8-8bd9-4754-b1d9-d4849efea2a7	2026-06-27 12:00:00+00	2026-06-27 13:00:00+00	Кара		completed	\N	\N	2026-06-24 17:35:50.795615+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
b3a7445c-e83f-4c58-9c28-c2a8551e077a	7a375784-31d4-427d-a1bf-a5007bba2c02	82ed251f-8eec-455f-8361-29b269564b16	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2026-06-29 20:00:00+00	2026-06-29 21:00:00+00	Viktor		completed	\N	\N	2026-06-29 12:08:33.245914+00	1	60	specialist	\N	\N	\N	\N	8520046459	657	\N
d9676571-53bb-47fc-9717-751cbec16c70	8dba2e99-0778-48a4-b243-ea784844fe52	56a9b95d-5ff8-4eed-9a16-497470f728a0	f9516972-fb3e-44aa-81e2-9e0593e0a4da	2026-04-30 13:00:00+00	2026-04-30 16:00:00+00	~		confirmed	\N	\N	2026-04-27 13:13:16.036189+00	1	180	\N	\N	\N	1153633029	20	\N	\N	\N
667b058b-9990-49dc-bc57-7225918873af	367d9abf-ff56-49c7-b210-79a6d694c22a	93002067-310a-40a9-9832-d377c6148a04	b8e13d7a-3411-4645-ab6c-d95c8431253e	2026-02-20 10:00:00+00	2026-02-20 11:00:00+00	Серж Наринян		cancelled		client	2026-02-19 14:54:51.220351+00	0	60	\N	\N	\N	734726332	10	\N	\N	\N
9866833f-9910-4805-b8de-c5f1ab153275	609308e0-556b-41e1-8b39-6a719c0dc6e9	341d8ef6-c9ec-455c-8f12-6b23c67a0253	ed0fa9c2-9eec-4f77-bc23-17057e81e9b4	2026-06-26 09:00:00+00	2026-06-26 10:00:00+00	Кара		completed	\N	\N	2026-06-24 16:38:00.499599+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
0d94dafb-c14c-46bc-8378-d94badbf4ea1	97fdb979-27db-4561-90ec-4b9deb66dfbe	7638f241-e1d5-4146-bd26-016a003487ab	a7272b78-d2f8-4927-b84d-ee327fa43f0d	2026-02-21 09:00:00+00	2026-02-21 10:30:00+00	Оля блондинка		completed	\N	\N	2026-02-17 19:26:57.145272+00	0	90	specialist	\N	\N	\N	\N	\N	\N	\N
e36416dd-6731-4ecc-99a5-361cdc35b05c	609308e0-556b-41e1-8b39-6a719c0dc6e9	1be66c35-98af-4caf-a6b6-797062450099	a933afb8-8bd9-4754-b1d9-d4849efea2a7	2026-06-27 11:00:00+00	2026-06-27 12:00:00+00	Karlen		completed	\N	\N	2026-06-24 17:14:14.041864+00	1	60	\N	\N	\N	873486696	9	\N	\N	\N
4e3c2e15-335e-4132-bc3c-7772fa7af028	8dba2e99-0778-48a4-b243-ea784844fe52	56a9b95d-5ff8-4eed-9a16-497470f728a0	fe41b94b-9eb5-4a7c-9593-8686c35d231f	2026-05-01 11:00:00+00	2026-05-01 12:00:00+00	~	Здравствуйте 	cancelled	rescheduled	\N	2026-04-27 13:02:33.421169+00	0	60	\N	\N	\N	1153633029	10	\N	\N	\N
80d4039c-6343-4048-b16a-3797512c3ce4	97fdb979-27db-4561-90ec-4b9deb66dfbe	df88a4da-e2f3-4b37-9006-d7cce1f28f42	16aad6f4-87c7-48b6-9597-7a97c35beacd	2026-04-28 09:00:00+00	2026-04-28 10:00:00+00	Мари		completed	\N	\N	2026-04-27 11:05:28.595049+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
a31452e6-5ad3-4c76-9ad7-5c8924d2a5fa	609308e0-556b-41e1-8b39-6a719c0dc6e9	1be66c35-98af-4caf-a6b6-797062450099	ed0fa9c2-9eec-4f77-bc23-17057e81e9b4	2026-06-24 22:00:00+00	2026-06-24 23:00:00+00	Karlen		completed	\N	\N	2026-06-24 17:16:16.118144+00	1	60	\N	\N	\N	873486696	11	\N	\N	\N
6839de4e-6a05-4e3b-b68f-44e5d8c82d11	97fdb979-27db-4561-90ec-4b9deb66dfbe	94e2175b-303a-400d-9e27-d6dbf4cf624c	d72bd21e-febe-412a-b9da-0e487baa8969	2026-04-27 18:30:00+00	2026-04-27 19:00:00+00	Олеся		completed	\N	\N	2026-04-27 11:11:53.359213+00	1	30	specialist	\N	\N	\N	\N	873486696	35	\N
5ffe3b99-583e-4e44-a12b-a17823fd6097	8dba2e99-0778-48a4-b243-ea784844fe52	56a9b95d-5ff8-4eed-9a16-497470f728a0	fe41b94b-9eb5-4a7c-9593-8686c35d231f	2026-04-29 10:00:00+00	2026-04-29 11:00:00+00	~		confirmed	\N	\N	2026-04-27 13:03:39.972177+00	1	60	specialist	\N	4e3c2e15-335e-4132-bc3c-7772fa7af028	\N	\N	\N	\N	\N
8f48c352-5fda-4864-a3eb-378eb3ffb1ba	97fdb979-27db-4561-90ec-4b9deb66dfbe	35b1872a-da8c-43d0-b831-c4bcd8c4e7e9	16aad6f4-87c7-48b6-9597-7a97c35beacd	2026-05-01 10:00:00+00	2026-05-01 11:00:00+00	Ирина Эпиляция (Авито)		completed	\N	\N	2026-04-28 17:18:28.127054+00	0	60	specialist	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: client_batches; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.client_batches (id, client_id, specialist_id, service_id, total_sessions, remaining_sessions, created_at, status) FROM stdin;
5d4883c8-ca17-46f0-845f-08e8f5f9052d	82ed251f-8eec-455f-8361-29b269564b16	7a375784-31d4-427d-a1bf-a5007bba2c02	c6b7f6a1-64fd-4f0e-9009-369b1171919a	10	10	2026-04-21 18:48:28.642671+00	active
3d12e230-7e32-45be-bd44-2027147f6d05	6a448566-62a4-4744-9799-c5edd8c0fdbd	609308e0-556b-41e1-8b39-6a719c0dc6e9	02dbd83c-7727-419f-8e24-829fdb30340e	10	10	2026-06-24 17:37:56.044176+00	active
5ea72159-3026-4010-9f38-b0354466fe84	1be66c35-98af-4caf-a6b6-797062450099	609308e0-556b-41e1-8b39-6a719c0dc6e9	02dbd83c-7727-419f-8e24-829fdb30340e	10	10	2026-06-24 17:46:11.720759+00	active
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.clients (id, telegram_user_id, specialist_id, name, created_at, phone, preferred_duration, notify_booking_status, notify_reminders, notify_days_off, notify_waitlist, photo_url, notify_cancellations, is_ghost, language, display_name, is_blocked, referred_via_code, telegram_username, photo_removed) FROM stdin;
8c13174e-6fe4-44d6-9bd4-79a7c86ff929	233812230	7a375784-31d4-427d-a1bf-a5007bba2c02	Daniil	2026-02-09 18:05:10+00	\N	60	1	1	0	1		1	0	ru		0	\N		0
d2845bfd-c02f-44af-b387-e08107b215ac	459457399	367d9abf-ff56-49c7-b210-79a6d694c22a	Карлен	2026-02-09 18:50:48+00		60	1	1	0	1		1	0	ru		0	\N		0
2e176978-a39c-4f8d-9d6f-3005926168ba	471284619	06b6bd71-b779-4a85-adc3-7b2f1f275c54	Kirill Zhuravlev	2026-02-09 19:20:47+00	\N	60	1	1	0	1		1	0	ru		0	\N		0
05f2ede3-eee9-4122-9612-e91d5fe40097	784529035	4bafd36c-342c-4be8-a355-e4fb87608828	zortik7	2026-02-09 21:11:34+00	7916499494	60	1	1	0	1		1	0	ru		0	\N		0
9c1d3fed-7a15-48ed-8880-75f8415a596d	468539823	06b6bd71-b779-4a85-adc3-7b2f1f275c54	Nastya R| Отдел заботы	2026-02-10 13:11:15+00	\N	60	1	1	0	1		1	0	ru		0	\N		0
4bbfb722-0c1a-4086-8609-56bbc7f2f96b	788276171	7a375784-31d4-427d-a1bf-a5007bba2c02	Андрей Колесников	2026-02-10 16:16:49+00	\N	60	1	1	0	1		1	0	ru		0	\N		0
03fc4a06-ba69-4f4c-ae4f-a73107a9f46d	188744019	4bafd36c-342c-4be8-a355-e4fb87608828	Artëm S	2026-02-12 15:10:42+00	\N	60	1	1	0	1		1	0	ru		0	\N		0
282dec3c-0219-43bc-ab29-1242b80ed002	864560981	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	Ivan Solyansky	2026-02-15 14:20:54.724454+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/7CeB8Q2_ST-dCRVhaSy4g-8Gvms-R6YZVlbYII6si1k.svg	1	0	ru		0	\N		0
7ca5ec17-5955-41ad-9f24-ecff756c0c57	459457399	7a375784-31d4-427d-a1bf-a5007bba2c02	Karlen	2026-02-08 00:53:30+00		90	1	1	1	1	https://t.me/i/userpic/320/H3ZPWehAVgd2IcG7EaWfGMY1tYiGJkMb_ScFWMn10ZU.svg	1	0	ru		0	\N		0
690c9ed4-5736-44bf-96e7-c1d663acafa4	1151538561	7a375784-31d4-427d-a1bf-a5007bba2c02	Артур	2026-02-14 10:39:08.532255+00	\N	60	1	1	0	1		1	0	ru		0	\N		0
93002067-310a-40a9-9832-d377c6148a04	734726332	367d9abf-ff56-49c7-b210-79a6d694c22a	Yapi Dor	2026-02-09 18:32:08+00		60	1	0	0	1	https://t.me/i/userpic/320/uivjCAqJnOK9zYcD3JHdsVlxjwTnxRCWWQkDwASoJ5w.svg	1	0	ru		0	\N		0
a7617e2e-291e-451a-bc52-384911d84e2c	734726332	7a375784-31d4-427d-a1bf-a5007bba2c02	Серж Наринян	2026-02-14 09:47:34.789019+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/uivjCAqJnOK9zYcD3JHdsVlxjwTnxRCWWQkDwASoJ5w.svg	1	0	ru		0	\N		0
ef71de5e-aa5e-4b61-a8db-5696366faabc	1098117089	97fdb979-27db-4561-90ec-4b9deb66dfbe	Мери	2026-02-10 11:41:50+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/uItujCRByXiE9NV-r4g3qmCeDnkhU7ijN3fwNfn497E.svg	1	0	ru		0	\N		0
bc4a218f-7d64-4cc0-9ce0-735e3f717d0e	784529035	7a375784-31d4-427d-a1bf-a5007bba2c02	zortik7	2026-02-14 19:28:45.894854+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/eFrlN-brb-X9vsl-ETZENByknWpa2LhYBirNsFIwKlc.svg	1	0	ru		0	\N		0
2575cd13-7d31-4e8e-b6e5-dfc61f2039b6	1202087215	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	Maria Borsheva	2026-02-15 15:39:35.114107+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/i1VaOR9uOlufZ5CUxSSKAdoFc_WWcXQGtzGCAfFMCLw.svg	1	0	ru		0	\N		0
92f31bb5-d99e-4ced-bc54-8cebd80223e7	-1771277643613983765	7a375784-31d4-427d-a1bf-a5007bba2c02	Тетя мотя	2026-02-16 21:34:03.615384+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
0b627858-a0ae-4884-ad5f-b2d3a02155c8	956025018	7a375784-31d4-427d-a1bf-a5007bba2c02	Kirill	2026-02-14 18:44:54.364104+00		60	1	0	1	1	https://t.me/i/userpic/320/NhTq_tCxuIR05CaWmsNGnwQCKokU1b9dXLOodCvLtek.svg	1	0	ru	Кирик	0	\N		0
86a64206-3501-4b99-9b62-f9443ca56a9a	-1771279756914013675	7a375784-31d4-427d-a1bf-a5007bba2c02	Петя друг	2026-02-16 22:09:16.927927+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
000e78f2-bd69-4904-a898-68f9091ee543	-1771282520607254230	7a375784-31d4-427d-a1bf-a5007bba2c02	Виктор	2026-02-16 22:55:20.61044+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
7638f241-e1d5-4146-bd26-016a003487ab	-1771356369206115937	97fdb979-27db-4561-90ec-4b9deb66dfbe	Оля блондинка	2026-02-17 19:26:09.206919+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
999a9fbc-ff57-48f9-bdf6-241bbd8dbad7	-1771277150787310198	7a375784-31d4-427d-a1bf-a5007bba2c02	Знакомый Кирилл	2026-02-16 21:25:50.788571+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
94e2175b-303a-400d-9e27-d6dbf4cf624c	873486696	97fdb979-27db-4561-90ec-4b9deb66dfbe	Олеся	2026-02-17 19:36:48.899588+00		60	1	1	0	1	https://t.me/i/userpic/320/BHmP2_FKOUi5KoElmanHAOW22BCuSoHRa5SJaVoZb90.svg	1	0	ru		0	\N		0
cbd3373b-515c-4942-915b-06dcd033e862	-1771507654561330783	7a375784-31d4-427d-a1bf-a5007bba2c02	Тим	2026-02-19 13:27:34.562104+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
b9bd5dde-5a55-44c0-af47-21875dcdb204	175941704	7a375784-31d4-427d-a1bf-a5007bba2c02	НеTim	2026-02-19 13:59:25.049101+00		60	1	1	0	1	https://t.me/i/userpic/320/hqmGSln8uEkQGfrnItQeBHXt50IHeM5mXFyI3DItd9o.svg	1	0	ru		0	\N		0
34bc4ae2-65f5-4ab0-8f90-5f6423911f55	-1772043095489807012	7a375784-31d4-427d-a1bf-a5007bba2c02	Карен	2026-02-25 18:11:35.490804+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
2e092da0-a066-4eef-8536-b13e9c64eea5	316908692	7a375784-31d4-427d-a1bf-a5007bba2c02	Roman Belsky	2026-02-12 15:11:44+00		60	1	1	0	1	https://t.me/i/userpic/320/Gb_Aevt2Sjy5kD776JCzEP33eB5MPLn8sEswQlMCSNA.svg	1	0	ru		0	\N		0
27617bf7-5092-4b76-a9ce-f9e2263b1fc5	6823397873	7a375784-31d4-427d-a1bf-a5007bba2c02	Viktor	2026-04-14 12:32:41.406587+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/cvVOpKaK7K9CBOGtqNojV9v-lSNIPcHK9Iy6nRO5OHH94UCCDY_JwYCXPvb7KHgx.svg	1	0	ru		0	\N		0
341d8ef6-c9ec-455c-8f12-6b23c67a0253	-1782319009936586232	609308e0-556b-41e1-8b39-6a719c0dc6e9	Кара	2026-06-24 16:36:49.937297+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
c15545ca-f1e4-4887-86cb-8b5cc52f426f	-1782319019591603165	609308e0-556b-41e1-8b39-6a719c0dc6e9	Кара	2026-06-24 16:36:59.59178+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
82ed251f-8eec-455f-8361-29b269564b16	8520046459	7a375784-31d4-427d-a1bf-a5007bba2c02	Viktor	2026-04-21 18:47:22.720627+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/8Iuxc3wzOA4nZHTXoD0N4JUSBaWjVbNHDoxalZLkcKT7aIDufWscvpMbcbk-P1Ie.svg	1	0	ru		0	\N	richsooooooon	0
d01a8221-6bdd-4024-8ed6-e45dff8d8103	-1777154661980806639	97fdb979-27db-4561-90ec-4b9deb66dfbe	Валентина Павловна	2026-04-25 22:04:21.981992+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
df88a4da-e2f3-4b37-9006-d7cce1f28f42	-1777287904878036096	97fdb979-27db-4561-90ec-4b9deb66dfbe	Мари	2026-04-27 11:05:04.878917+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
8030a303-9df4-4b5c-9366-fe6730219273	459457399	97fdb979-27db-4561-90ec-4b9deb66dfbe	Karlen	2026-06-14 14:27:07.359093+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/H3ZPWehAVgd2IcG7EaWfGMY1tYiGJkMb_ScFWMn10ZU.svg	1	0	ru		0	\N	karlenptsd	0
e360c996-30fe-4ae0-b14e-29f345eabab1	1153633029	8dba2e99-0778-48a4-b243-ea784844fe52	Ирина	2026-04-27 12:42:26.508857+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/k2IZaRDxom2HaoExUGd4OxpraTYfFTPzfvaZRE_MmcQ.svg	1	0	ru		0	\N		0
e9ce13f4-d83c-455a-a827-dc461063b8e7	8520046459	2d8f2756-6958-4197-8b07-1238d0005781	Viktor	2026-06-23 16:19:39.444342+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/8Iuxc3wzOA4nZHTXoD0N4JUSBaWjVbNHDoxalZLkcKT7aIDufWscvpMbcbk-P1Ie.svg	1	0	ru		0	\N		0
56a9b95d-5ff8-4eed-9a16-497470f728a0	873486696	8dba2e99-0778-48a4-b243-ea784844fe52	~	2026-04-27 13:01:48.624857+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/BHmP2_FKOUi5KoElmanHAOW22BCuSoHRa5SJaVoZb90.svg	1	0	ru		0	\N	Druada	0
bea44348-f5be-42de-ba4f-eca79f759baa	1779702658	8dba2e99-0778-48a4-b243-ea784844fe52	ate	2026-04-27 13:04:13.875356+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/_Fs3Ay-BPXbQ8AbJ1xFoqcKqAGuFVBfoXsOUlnmn0tk.svg	1	0	ru		0	\N	kirimanu	0
35b1872a-da8c-43d0-b831-c4bcd8c4e7e9	-1777396690556865024	97fdb979-27db-4561-90ec-4b9deb66dfbe	Ирина Эпиляция (Авито)	2026-04-28 17:18:10.558153+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
21b168c0-e521-4532-84a4-9128d3030804	-1777562442431683069	7a375784-31d4-427d-a1bf-a5007bba2c02	Игроь	2026-04-30 15:20:42.432722+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
12275b15-6449-477f-9877-be42343ca62b	-1778574587601378313	7a375784-31d4-427d-a1bf-a5007bba2c02	Петя	2026-05-12 08:29:47.60208+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
cc612e3d-e163-475d-8ccd-839cd0a8030b	-1782232298001588105	2d8f2756-6958-4197-8b07-1238d0005781	Иван	2026-06-23 16:31:38.002307+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
789e79bf-8baf-462a-a8f4-16cf666cd827	-1782232347329278964	2d8f2756-6958-4197-8b07-1238d0005781	Клиент	2026-06-23 16:32:27.33068+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
f5a4fd69-c8ed-420d-93e7-b1b9a27b0990	873486696	609308e0-556b-41e1-8b39-6a719c0dc6e9	~	2026-06-24 16:35:26.07546+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/BHmP2_FKOUi5KoElmanHAOW22BCuSoHRa5SJaVoZb90.svg	1	0	ru		0	\N		0
1be66c35-98af-4caf-a6b6-797062450099	459457399	609308e0-556b-41e1-8b39-6a719c0dc6e9	Karlen	2026-06-24 17:13:33.424136+00	\N	60	1	1	0	1	https://t.me/i/userpic/320/H3ZPWehAVgd2IcG7EaWfGMY1tYiGJkMb_ScFWMn10ZU.svg	1	0	ru		0	\N		0
6a448566-62a4-4744-9799-c5edd8c0fdbd	-1782322592385573037	609308e0-556b-41e1-8b39-6a719c0dc6e9	Амир	2026-06-24 17:36:32.38637+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
c2ec90e5-f311-466d-a16d-57b796f5cd28	-1782322718325174810	609308e0-556b-41e1-8b39-6a719c0dc6e9	Наташа	2026-06-24 17:38:38.326111+00	\N	60	1	1	0	1		1	1	ru		0	\N		0
\.


--
-- Data for Name: dashboard_audit_log; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.dashboard_audit_log (id, actor_telegram_id, method, path, action, specialist_id, status_code, created_at) FROM stdin;
\.


--
-- Data for Name: days_off; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.days_off (id, specialist_id, date, reason, created_at) FROM stdin;
65b21ed4-ebf2-4bbf-aa73-2a1cc25de3e3	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-02-05	\N	2026-02-09 23:10:45+00
7732ab72-a65d-483c-8e41-5fa681e7247c	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-02-11	\N	2026-02-12 10:33:03+00
f48138b6-e3d9-4cf9-90a4-1ac98bd0d07b	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-02-12	\N	2026-02-13 18:52:12+00
d353bec2-1586-453d-94d5-b715fe076523	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-03-27	\N	2026-02-16 22:54:43.330452+00
530902dc-1455-4fde-887a-987c0f454fbe	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-04-08	\N	2026-04-20 18:59:46.013213+00
d7a12f34-03ea-495b-b1d1-5dadedabafc2	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-04-09	\N	2026-04-20 18:59:46.013213+00
fbdd34fb-f00b-4093-a5b6-46baac3b16a2	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-04-10	\N	2026-04-20 18:59:46.013213+00
75762dd5-35bd-4224-966a-7c9b137c360a	7a375784-31d4-427d-a1bf-a5007bba2c02	2026-04-11	\N	2026-04-20 18:59:46.013213+00
\.


--
-- Data for Name: master_users; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.master_users (telegram_user_id, language, first_seen_at, last_seen_at) FROM stdin;
459457399	ru	2026-04-29 12:50:58.07772+00	2026-04-29 12:51:01.796988+00
\.


--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.promo_codes (id, code, discount_type, discount_value, duration_days, max_redemptions, redemptions_count, valid_from, valid_until, applies_to_plan, referral_specialist_id, is_active, created_at) FROM stdin;
46a98b78-07c1-440b-b220-1c0a672fa399	HGFDJ	percent	80	0	50	0	\N	\N			1	2026-06-15 12:30:59.00337+00
dcbd2a2a-2f0e-4b6b-af86-3c7f95ac973c	FRRGB	percent	100	0	10	1	\N	\N			0	2026-06-15 12:56:18.214852+00
42df21ad-b534-4f2c-8230-fdb3fd62aaf6	ASDFG	percent	99	0	1	0	\N	\N			1	2026-06-15 16:20:30.89361+00
27029e97-4744-449d-9d50-61f9d8b8ee96	OLESYA	percent	99	0	2	0	\N	\N			0	2026-06-15 17:27:31.049086+00
\.


--
-- Data for Name: promo_redemptions; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.promo_redemptions (id, promo_code_id, specialist_id, payment_id, discount_kopecks, created_at) FROM stdin;
fa4346a6-246f-45f5-9872-604638a60526	dcbd2a2a-2f0e-4b6b-af86-3c7f95ac973c	7a375784-31d4-427d-a1bf-a5007bba2c02	37d12f86-caa9-4865-b46f-ae6b69418f14	499000	2026-06-15 13:17:48.63296+00
\.


--
-- Data for Name: recurring_schedules; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.recurring_schedules (id, specialist_id, client_id, client_name, day_of_week, "time", duration_minutes, status, created_by, created_at, session_type_id, days_of_week, start_date, end_date, day_times) FROM stdin;
3925e679-cb39-4d33-b3c8-080b31ff6a6d	7a375784-31d4-427d-a1bf-a5007bba2c02	bc4a218f-7d64-4cc0-9ce0-735e3f717d0e	zortik7	2	13:30	60	declined	client	2026-02-14 19:29:56.318587+00	fc648f70-59ed-43b6-84e6-ed145dbbf14e	2	2026-02-15	2026-03-15	\N
9123acf9-5543-4f88-8b08-c128e77e555f	7a375784-31d4-427d-a1bf-a5007bba2c02	0b627858-a0ae-4884-ad5f-b2d3a02155c8	Kirill	1	11:30	60	pending	specialist	2026-02-16 14:32:10.157927+00	fc648f70-59ed-43b6-84e6-ed145dbbf14e	1,3,5	2026-02-17	2026-03-17	{"1":"11:30","3":"12:00","5":"15:30"}
\.


--
-- Data for Name: session_types; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.session_types (id, specialist_id, type, name, duration_minutes, price, currency, is_active, image_url, sessions_count) FROM stdin;
c6b7f6a1-64fd-4f0e-9009-369b1171919a	7a375784-31d4-427d-a1bf-a5007bba2c02	batch	Тренировка	60	25000	RUB	1		10
10109c9b-3ef6-4487-8207-3190e4730386	2d8f2756-6958-4197-8b07-1238d0005781	common	Персональный сеанс	60	3000	RUB	1		\N
fc648f70-59ed-43b6-84e6-ed145dbbf14e	7a375784-31d4-427d-a1bf-a5007bba2c02	common	Персональная тренировка	60	3000	RUB	1		\N
701c8d08-f532-4226-8554-ba5d493812f2	7a375784-31d4-427d-a1bf-a5007bba2c02	common	Парная тренировка	90	4500	RUB	1		\N
02765fe9-bf83-47a9-b220-71c4dc20dec3	8dba2e99-0778-48a4-b243-ea784844fe52	common	Составление документов, иски,ходатайств 	60	10000	RUB	1		\N
5baac64a-9801-46e2-81f6-f9526bc16f85	8dba2e99-0778-48a4-b243-ea784844fe52	common	Представительство в суде , защита интересов в судах	180	50000	RUB	0		\N
37122734-af50-4597-9e69-d9d8f3c9b286	8dba2e99-0778-48a4-b243-ea784844fe52	common	Уголовная защита 	180	100000	RUB	1		\N
f9516972-fb3e-44aa-81e2-9e0593e0a4da	8dba2e99-0778-48a4-b243-ea784844fe52	common	Правовая экспертиза , анализ документов,	180	15000	RUB	1		\N
c468d8ad-1805-478b-8ac9-be5a82d3404c	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	common	Консультация	30	1500	RUB	1		\N
4b869ca0-5ab3-45e7-b2c1-338879133f20	367d9abf-ff56-49c7-b210-79a6d694c22a	common	Персональная тренировка	60	3000	RUB	1		\N
b8e13d7a-3411-4645-ab6c-d95c8431253e	367d9abf-ff56-49c7-b210-79a6d694c22a	common	Парная тренировка	60	4500	RUB	1		\N
ff2d68b2-c8ac-44f6-a3ae-0eac92cced87	367d9abf-ff56-49c7-b210-79a6d694c22a	common	Консультация	30	1500	RUB	1		\N
a2341cfe-7aa4-461a-b0cf-243ecceec6c2	06b6bd71-b779-4a85-adc3-7b2f1f275c54	common	Персональная тренировка	60	4000	RUB	1		\N
9745e3f2-b55a-4b04-bec7-25512dbb8183	06b6bd71-b779-4a85-adc3-7b2f1f275c54	common	Парная тренировка	60	5600	RUB	1		\N
667f888e-f91e-4aa0-8314-c5298985fed6	06b6bd71-b779-4a85-adc3-7b2f1f275c54	common	Консультация	30	2000	RUB	1		\N
b3251718-3013-4f38-bef7-d99fa6491aa4	4bafd36c-342c-4be8-a355-e4fb87608828	common	Персональная тренировка	60	30000	RUB	1		\N
e6365224-b927-417f-b282-a0a70b08c160	4bafd36c-342c-4be8-a355-e4fb87608828	common	Парная тренировка	90	4500	RUB	1		\N
3d4b955b-44e6-4848-ae3c-39c7384a96ad	4bafd36c-342c-4be8-a355-e4fb87608828	common	Консультация	30	1500	RUB	1		\N
16aad6f4-87c7-48b6-9597-7a97c35beacd	97fdb979-27db-4561-90ec-4b9deb66dfbe	common	Электроэпиляция	60	1500	RUB	1		\N
ed0fa9c2-9eec-4f77-bc23-17057e81e9b4	609308e0-556b-41e1-8b39-6a719c0dc6e9	common	Персональный сеанс	60	3000	RUB	1		\N
20c1e069-7ccf-4599-9353-aba8d49f76ae	609308e0-556b-41e1-8b39-6a719c0dc6e9	batch	Трени	75	2500	RUB	1		5
d72bd21e-febe-412a-b9da-0e487baa8969	97fdb979-27db-4561-90ec-4b9deb66dfbe	common	Ламинирование ресниц 	30	0	RUB	1		\N
fe41b94b-9eb5-4a7c-9593-8686c35d231f	8dba2e99-0778-48a4-b243-ea784844fe52	common	Консультирование -устное и письменное 	60	5000	RUB	1		\N
a31108d8-f65a-4222-81a0-a022c595c20e	8dba2e99-0778-48a4-b243-ea784844fe52	common	Представительство в госорганах	180	20000	RUB	1		\N
49179e93-e523-4be5-9b9b-bd9c53cf53ef	8dba2e99-0778-48a4-b243-ea784844fe52	common	Досудебное урегулирование- переговоры	180	20000	RUB	1		\N
316893c1-e16f-427e-85ce-00295e518007	8dba2e99-0778-48a4-b243-ea784844fe52	common	Сбор доказательств	60	10000	RUB	1		\N
0e98e11e-6018-4a4d-994b-32f349cd383b	8dba2e99-0778-48a4-b243-ea784844fe52	common	Подготовка жалоб в надзорные органы 	60	10000	RUB	1		\N
0ecfab49-292e-483a-bccb-3f2c1506229b	97fdb979-27db-4561-90ec-4b9deb66dfbe	common	Коррекция 	60	4000	RUB	1		\N
a7272b78-d2f8-4927-b84d-ee327fa43f0d	97fdb979-27db-4561-90ec-4b9deb66dfbe	common	Перманентный макияж 	90	6000	RUB	1		\N
b1a403cc-c54c-4239-ab61-5c025c2232e0	caf90a65-a287-474f-bc9b-c9da6ad8ab30	common	Персональная тренировка	60	3000	RUB	1		\N
180aea31-98f0-457a-90d9-ecf1f09a7a62	caf90a65-a287-474f-bc9b-c9da6ad8ab30	common	Парная тренировка	60	4500	RUB	1		\N
0ff48f80-c360-4f60-bd92-0b286eb3f6e0	caf90a65-a287-474f-bc9b-c9da6ad8ab30	common	Консультация	30	1500	RUB	1		\N
65a3c0ff-d7c2-4629-9d4b-6838bd42f71a	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	common	Персональная тренировка	60	3000	RUB	1		\N
45ab27e8-1d51-400b-b9db-10100af2bb1d	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	common	Парная тренировка	60	4500	RUB	1		\N
a933afb8-8bd9-4754-b1d9-d4849efea2a7	609308e0-556b-41e1-8b39-6a719c0dc6e9	common	Перманент бровей 	60	7000	RUB	1		\N
e9e805c4-f97b-43df-8177-b1c12f59709f	7a375784-31d4-427d-a1bf-a5007bba2c02	common	Консультация	30	1500	RUB	1		\N
c7a2d1a2-51c3-4829-8724-bc7894d88d42	7a375784-31d4-427d-a1bf-a5007bba2c02	common	Лол кек	45	5000	RUB	1		\N
02dbd83c-7727-419f-8e24-829fdb30340e	609308e0-556b-41e1-8b39-6a719c0dc6e9	batch	Отр	60	3000	RUB	1		10
\.


--
-- Data for Name: specialists; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.specialists (id, telegram_user_id, bot_token, bot_username, webhook_secret, name, timezone, cancel_cutoff_hrs, is_active, created_at, telegram_handle, phone, specialization, bio, photo_url, bot_token_hash, location_latitude, location_longitude, location_address, available_durations, notify_new_bookings, notify_cancellations, language, wallpaper, referral_code, deleted_at, referred_via_code, first_payment_at, photo_removed, subscription_status, subscription_plan, trial_ends_at, subscription_started_at, current_period_end_at, auto_renew, cancel_at_period_end, yookassa_payment_method_id, email, has_trialed, consent_accepted_at, consent_version, cancel_cutoff_enabled) FROM stdin;
4bafd36c-342c-4be8-a355-e4fb87608828	784529035	enc:yWDcQ2nvJQSksf3acfgpEt9T6TKOkQ4iSbaGniqnqvMuN2np9N8nQN87Ufhf6vDk0RnVgnmjpzd/HJ6rI/Y1HzOHV1IK1sNQohI=	trener_Mike_bot	59aa9e9d995bcaeb2cfc309366c9bd81f670cc3fe601b75ee5cf2e1c139f0825	Майк	Europe/Moscow	24	1	2026-02-09 21:11:21+00	zortik7					60c660937f3fb7fb3ceb2807f3efca6f8a1ff2ffa2ee80e01efd253f952e3318	0	0	\N	60,90,120,150	1	1	ru		263e84cce095f61a	\N	\N	\N	0	active	pro	\N	2026-06-13 15:11:08.782331+00	2026-07-13 15:11:08.782331+00	1	0	\N	\N	1	\N		0
caf90a65-a287-474f-bc9b-c9da6ad8ab30	233812230	enc:LtQK3TMcMGaB1yYuFxY1MsLFTj6H4/zr7NS8KXVMxomEIZvNMaedv6Wm43F25m+r09qauoSm4McfAuU+CO5amJF2BSwOcIVQ9do=	karlen_2_bot	aba3e3adede42b7424f87321d1bc0de9259a12aa0da6a0dacb98fc80f4f42fb6	карл	Europe/Moscow	24	1	2026-02-10 16:52:29+00	w84april					04c18886bb7122eed7e2f1d0650e7c616592124f3bd277f24ec881432cade49f	0	0	\N	\N	1	1	ru		73633e388ff1fa6e	\N	\N	\N	0	active	pro	\N	2026-06-13 15:11:08.782331+00	2026-07-13 15:11:08.782331+00	1	0	\N	\N	1	\N		0
05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	864560981	enc:V/ET2AaCy7qo/IhDGKnUwlE1NGUYIna/7NsUSajc/dkDjKCUyVqKAlZj+cxTSK1oWQfMcC3l6j6Ip9NtEfbj0V1TvtylocAs5rI=	Trener_ivan_bot	0b6849fc4edb3d3be8d3a106187ea58e9f8fcc13bee98dadc9333453fa68e82d	Тренер Иван	Europe/Moscow	24	1	2026-02-15 14:18:38.416191+00	SolyanskiyIvan					c18673f2340f09b98966e734b8309ff39375e02cd2e5d44c3cdbda2c39a0e59e	0	0	\N	\N	1	1	ru		00ea00e181d789b3	\N	\N	\N	0	active	pro	\N	2026-06-13 15:11:08.782331+00	2026-07-13 15:11:08.782331+00	1	0	\N	\N	1	\N		0
7a375784-31d4-427d-a1bf-a5007bba2c02	459457399	enc:+TMPz6KTR15+1AE2sQxN/lULp/VOFs49Q/OeEi6XqhNPVqqs45oAjd5WsYIAu+ixgMQWSdQAB1tPM++y1MNOb5prqqi0XQ8jniQ=	testttt01bot	42355d6cdcb8bc4a05b4211bbd279e3863e1e17cce47766b97fb464b37a4082c	Карлен Мисакян	Europe/Moscow	24	1	2026-02-08 00:00:26+00	karlenptsd		Тренер	Я тренер по фитнесу	AgACAgIAAxkDAAICfmotp7ffHNaL2Xd5NxPYYMTz4hYhAAI8JGsbYSpoSblSc_LsjBOdAQADAgADdwADPAQ	ff8ef5f2a159321f0bb42653cccd28a08a4292a7266d36fcd98ce4d67c7f4acd	47.23038	38.86899		60,90,120	0	0	ru	teaching	79bdac040fa63738	\N	\N	2026-06-15 13:17:48.63296+00	0	active	pro_annual	\N	2026-06-13 15:11:08.782331+00	2027-07-13 15:11:08.782331+00	0	1	\N	\N	1	\N		1
06b6bd71-b779-4a85-adc3-7b2f1f275c54	471284619	enc:KhinFgz0M1HD4vlPCxdgA9oks1e9Bb7Inl57tgD0065OgminRxjfB72C1ezzU5GprDJyF9M44rZ5t4v6VmwR9XcLrWt8pfrkXbY=	trainer_kirill_bot	90415a76abc722aee33bb110e3db0babcb0e5a5d4a4669c486bfaf624980192c	Кирилл	Europe/Moscow	24	1	2026-02-09 19:20:17+00	zhuravlcoach		Персональный тренер			156ec648053c2774149a3e525864a8551c6646dd31509a057f02dce24aeb4604	0	0	\N	60,90,120	1	1	ru		9653efaf6c8fc599	\N	\N	\N	0	active	pro	\N	2026-06-13 15:11:08.782331+00	2026-07-13 15:11:08.782331+00	1	0	\N	\N	1	\N		0
8dba2e99-0778-48a4-b243-ea784844fe52	1153633029	enc:L4qsMOmtM2RtYTtwgq9mUu1xAIbar5tOBmyqrFgkoHOq7vR+GlLOdQV+hMnrWotATX4gxoaFeFjq5rp4btI1KLCX2jhLR9SW18o=	irina_advokat_bot	2d35396c02ca57d0b573e235f27f06e1162019394fae517ef843145b9ac88904	Горбань Ирина Алексеевна адвокат	Europe/Moscow	24	1	2026-04-27 12:40:39.626637+00	Irinagorba				https://t.me/i/userpic/320/k2IZaRDxom2HaoExUGd4OxpraTYfFTPzfvaZRE_MmcQ.svg	a4449d86f1e38b4e11036358846f7f46c9ad1e79d73fda195fd898a937e7476a	0	0	\N	\N	1	1	ru		bc0e817a3f92ca71	\N	\N	\N	0	active	pro	\N	2026-06-13 15:11:08.782331+00	2026-07-13 15:11:08.782331+00	1	0	\N	\N	1	\N		0
97fdb979-27db-4561-90ec-4b9deb66dfbe	1098117089	enc:KZqzQd2T3Z0hqK8cFzC2nYI8LRqJxkWSvOmLv9J9mWo/4W0e42N51yTKGTDSfv+6x51dQ3rb7uWpGThj51pa2y8b1d7hs4ecjcA=	meri_permanent_bot	22d9a0a30cf450418129c8613b859fd64b4303c53bd466afd88286f49cb43a6b	Мери Наринян	Europe/Moscow	24	1	2026-02-10 11:40:37+00		89188555696	Мастер перманентного макияжа 		https://t.me/i/userpic/320/uItujCRByXiE9NV-r4g3qmCeDnkhU7ijN3fwNfn497E.svg	08cf28ae658f2eadc242ab2a9e52d8253201a2ef3998821e752b20110de089db	47.234451	38.877118	\N	\N	1	1	ru		9438624e6ad521c1	\N	\N	\N	0	active	pro	\N	2026-06-13 15:11:08.782331+00	2026-07-13 15:11:08.782331+00	1	0	\N	\N	1	\N		0
2d8f2756-6958-4197-8b07-1238d0005781	8520046459	enc:8haplRe9TRFAS/8dFkv06sVksX5Xw1tpCJJg/CP1BVmPKO3MXQP/jO4lvy9W/akaXh9njobmVw2u3on1hWo1/2vjfJ4V8kfnPtQ=	viktortestttbot	a206310134043f26156fa675b716fcc9105206160c0261f9cbd370aa0cc91618	Viktor	Europe/Moscow	24	1	2026-06-16 13:17:18.191355+00	richsooooooon				https://t.me/i/userpic/320/8Iuxc3wzOA4nZHTXoD0N4JUSBaWjVbNHDoxalZLkcKT7aIDufWscvpMbcbk-P1Ie.svg	4eeb38294e3c9ff46d63468ac4379a4f902461004074bc616de136cb00dedcd0	0	0	\N	\N	1	1	ru		31e74d290c29c75a	\N	\N	\N	0	cancelled	pro	2026-06-15 00:00:00+00	\N	\N	1	0	\N	raininggmann@proton.me	1	2026-06-16 13:17:18.20623	1.0	0
367d9abf-ff56-49c7-b210-79a6d694c22a	734726332	enc:4sqeKRrYsvVyLlWjPnob5CmjlnqB1L/E2OCaux00BSXMm4xDdZ50sjXXWWOZe9oA/ppe5ohgS7F8OvWjt5oV2yq/g+VDLCIVB9Q=	Trener_Serzh_bot	7cb1c5cd933c843d5cf174b46708b292fe91bffac9a17175635c5121f9714336	Серж Наринян	Europe/Moscow	24	1	2026-02-09 18:31:15+00	Nanar1n				https://t.me/i/userpic/320/uivjCAqJnOK9zYcD3JHdsVlxjwTnxRCWWQkDwASoJ5w.svg	f97184af1ca6171bee457e24b742465989e5402bb40834ba26a6738a92f888d3	0	0	\N	\N	1	1	ru		a62687f735103c20	\N	\N	\N	0	active	pro	\N	2026-06-13 15:11:08.782331+00	2026-07-13 15:11:08.782331+00	1	0	\N	\N	1	\N		0
609308e0-556b-41e1-8b39-6a719c0dc6e9	873486696	enc:Sw/pIcwiEQAuKZAyT8OuU1KU5CZ/Z1+EVbpM+B9TXZz1RhUzAMfS7YCPV012M0gIZfj+6tJWUkvTJeJ124TrFdr3v7nPp+85WGI=	olesia_permanent_bot	7c733b7fb38ec285817de03d250913c960b85ee2f05bdcae913f48a3fd8fd7d6	Олеся	Europe/Moscow	24	1	2026-06-24 16:34:20.312383+00	Druada				telegram:AgACAgIAAxUAAWo8B1m2stXXbygkTBx8swABuQl_QwACuacxG2hZEDQ-g3qCTJoXKAEAAwIAA2MAAzwE	38222332043a0b0015cc540de578a7abda881cf8f70e881e26c6db61e88e9214	0	0	\N	\N	1	1	ru		425bfe87bb200852	\N	\N	\N	0	trialing	pro	2026-07-08 16:34:20.310743+00	\N	\N	1	0	\N	oshurapej@mail.ru	1	2026-06-24 16:34:20.352963	1.0	0
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.subscription_payments (id, specialist_id, yookassa_payment_id, amount_kopecks, currency, status, plan_code, promo_code, discount_kopecks, period_start, period_end, is_renewal, payment_method_id, created_at, paid_at, raw_payload) FROM stdin;
70408b2b-85a3-4317-b0fe-69e6a1ba87c2	7a375784-31d4-427d-a1bf-a5007bba2c02	31bfbe49-000f-5001-9000-1cff23d263bd	59000	RUB	pending	pro_monthly		0	2026-06-13 19:07:53.058254+00	2026-07-13 19:07:53.058254+00	0		2026-06-13 19:07:53.058254+00	\N	
430e11c9-e8a8-4945-a1c0-cf64af7a33fa	7a375784-31d4-427d-a1bf-a5007bba2c02	31bfbe90-000f-5001-8000-1e400058c57b	499000	RUB	pending	pro_annual		0	2026-06-13 19:09:04.79264+00	2027-06-13 19:09:04.79264+00	0		2026-06-13 19:09:04.79264+00	\N	
b8056d78-75e3-47d1-a9ad-650822ec4fef	7a375784-31d4-427d-a1bf-a5007bba2c02	31bfbeb6-000f-5000-b000-14c197aa5ab8	149000	RUB	pending	pro_quarterly		0	2026-06-13 19:09:42.677705+00	2026-09-11 19:09:42.677705+00	0		2026-06-13 19:09:42.677705+00	\N	
37d12f86-caa9-4865-b46f-ae6b69418f14	7a375784-31d4-427d-a1bf-a5007bba2c02	promo_def62332-d806-41bc-904b-2fe259d6a7cc	0	RUB	succeeded	pro_annual	FRRGB	499000	2026-06-15 13:17:48.63296+00	2027-07-13 15:11:08.782331+00	0		2026-06-15 13:17:48.63296+00	2026-06-15 13:17:48.63296+00	
4140fbe2-cd6c-405c-930a-ec0ba2b583f2	7a375784-31d4-427d-a1bf-a5007bba2c02	31c21d22-000f-5001-9000-14dd52e43054	59000	RUB	pending	pro_monthly		0	2026-06-15 14:17:06.278928+00	2026-07-15 14:17:06.278928+00	0		2026-06-15 14:17:06.278928+00	\N	
bd6186ad-f85e-4c1b-a91b-e9144c5046b3	7a375784-31d4-427d-a1bf-a5007bba2c02	31c34f54-000f-5001-8000-15fbeb238e82	59000	RUB	pending	pro_monthly		0	2026-06-16 12:03:32.726986+00	2026-07-16 12:03:32.726986+00	0		2026-06-16 12:03:32.726986+00	\N	
9e6f7988-d75a-4ff0-b9d9-d2a074c79048	7a375784-31d4-427d-a1bf-a5007bba2c02	31c34fa6-000f-5001-9000-166ba5df44c8	59000	RUB	pending	pro_monthly		0	2026-06-16 12:04:54.064346+00	2026-07-16 12:04:54.064346+00	0		2026-06-16 12:04:54.064346+00	\N	
\.


--
-- Data for Name: support_threads; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.support_threads (id, telegram_user_id, telegram_username, display_name, language_code, topic_id, created_at, last_message_at, closed_at) FROM stdin;
f94bc768-ce1d-4e41-88b7-51f18ce4c750	773859541	bina_MD	БИНА	ru	124	2026-05-12 08:34:32.378892+00	2026-05-12 08:34:41.760965+00	2026-05-12 08:39:56.926791+00
258a0673-023a-4ae6-bd79-823ef50447a3	8520046459		Viktor	en	78	2026-04-21 14:50:03.410865+00	2026-06-15 16:06:19.713298+00	2026-06-15 16:11:22.65306+00
cc594e73-81af-4267-8ded-a14ba78c08f5	459457399	karlenptsd	Karlen	en	138	2026-04-20 16:05:31.94035+00	2026-06-29 12:55:32.183222+00	2026-06-29 13:01:01.998565+00
0fb3ba3e-9298-47c0-ac04-22c72bed0105	873486696	Druada	~	ru	40	2026-04-20 16:07:17.558072+00	2026-04-20 16:38:39.768585+00	2026-04-22 12:19:35.074689+00
d03b2a10-5970-4a72-9409-ad5100fb675d	7767373649		Грег	ru	53	2026-04-20 17:31:36.441846+00	2026-04-20 17:38:22.183989+00	2026-04-22 12:19:35.379943+00
5b8508f8-b67a-4e5c-bd06-cfc1462a16a7	6823397873	richsoooon	Viktor	en	75	2026-04-21 14:25:24.756739+00	2026-04-21 14:25:36.701193+00	2026-04-22 12:19:35.571614+00
\.


--
-- Data for Name: trainers; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.trainers (id, telegram_user_id, bot_token, bot_username, webhook_secret, name, timezone, cancel_cutoff_hrs, is_active, created_at, telegram_handle, phone, specialization, bio, photo_url, bot_token_hash, gym_latitude, gym_longitude, gym_address, available_durations, notify_new_bookings, notify_cancellations) FROM stdin;
\.


--
-- Data for Name: waitlist; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.waitlist (id, specialist_id, client_id, starts_at, ends_at, duration_minutes, client_name, status, offered_at, created_at) FROM stdin;
\.


--
-- Data for Name: working_hours; Type: TABLE DATA; Schema: public; Owner: scheduler
--

COPY public.working_hours (id, specialist_id, day_of_week, start_time, end_time) FROM stdin;
3dc20ac9-51bd-4efe-a3b2-16a77bd8222f	367d9abf-ff56-49c7-b210-79a6d694c22a	1	09:00	18:00
196ff177-071b-41b1-a70c-982ad056ba02	367d9abf-ff56-49c7-b210-79a6d694c22a	2	09:00	18:00
2ff2bea3-d907-4043-9cf1-f5a36e826c25	367d9abf-ff56-49c7-b210-79a6d694c22a	3	09:00	18:00
5f6ae305-2531-444e-98df-8e82b9a62bb9	367d9abf-ff56-49c7-b210-79a6d694c22a	4	09:00	18:00
33c054bc-b7d3-472a-a311-e3d8f0f08a48	367d9abf-ff56-49c7-b210-79a6d694c22a	5	09:00	18:00
adb224c5-6a7c-4194-beaf-51e691451615	367d9abf-ff56-49c7-b210-79a6d694c22a	6	10:00	15:00
e80eda36-849f-469b-98b9-b988f95c4b7c	06b6bd71-b779-4a85-adc3-7b2f1f275c54	1	12:00	18:00
bfea9868-0314-45cc-a075-3a4c7b47b8fb	06b6bd71-b779-4a85-adc3-7b2f1f275c54	2	12:00	18:00
f8941065-51b2-4ddb-b920-1d6d8359791e	06b6bd71-b779-4a85-adc3-7b2f1f275c54	3	12:00	18:00
85b338ce-c3a8-4d79-b6b4-fcda7a57faf8	06b6bd71-b779-4a85-adc3-7b2f1f275c54	4	12:00	18:00
558a328b-939b-4390-aa22-c8a268d957c7	06b6bd71-b779-4a85-adc3-7b2f1f275c54	5	12:00	18:00
6a81ad2c-5378-4e0e-adc3-0e8063f92969	4bafd36c-342c-4be8-a355-e4fb87608828	1	09:00	18:00
27125dfd-cc75-43cf-9ca7-a2665fb654e2	4bafd36c-342c-4be8-a355-e4fb87608828	2	09:00	18:00
83b9ac9d-671b-40f7-8bd8-dc4034001058	4bafd36c-342c-4be8-a355-e4fb87608828	3	09:00	18:00
d394fe4b-4a23-431a-9387-c95283c7fd8b	4bafd36c-342c-4be8-a355-e4fb87608828	4	09:00	18:00
2c020501-ed9f-49f2-962f-186637d04752	4bafd36c-342c-4be8-a355-e4fb87608828	5	09:00	18:00
c39902ef-b1c8-45e3-bdb7-84b6a618cc52	4bafd36c-342c-4be8-a355-e4fb87608828	6	10:00	15:00
35310eeb-c153-46b1-abbb-2515fda407dc	7a375784-31d4-427d-a1bf-a5007bba2c02	1	09:00	11:00
888be097-771c-4f18-8525-390fe6cc7220	7a375784-31d4-427d-a1bf-a5007bba2c02	1	13:00	24:00
235c6c92-205b-4ac1-beb4-e2d59f8b654b	7a375784-31d4-427d-a1bf-a5007bba2c02	2	09:00	20:00
e33ddd33-9991-4238-94e9-69b9d9271c0b	7a375784-31d4-427d-a1bf-a5007bba2c02	3	09:00	23:00
16d87a80-1479-4613-b921-61f339a68d4d	7a375784-31d4-427d-a1bf-a5007bba2c02	4	09:00	23:00
5f59a309-c3e1-444e-8234-4f125f44161a	7a375784-31d4-427d-a1bf-a5007bba2c02	5	09:00	23:00
0ea94b5b-347c-4997-9e05-db3b09cdbf70	caf90a65-a287-474f-bc9b-c9da6ad8ab30	1	09:00	18:00
fff4a600-f973-4d4e-84c7-488c3fe63f95	caf90a65-a287-474f-bc9b-c9da6ad8ab30	2	09:00	18:00
3e6e508a-d6e5-48f7-8925-08ba1fc9368e	caf90a65-a287-474f-bc9b-c9da6ad8ab30	3	09:00	18:00
a50c43f1-08e1-4b77-a254-2ac045d238de	caf90a65-a287-474f-bc9b-c9da6ad8ab30	4	09:00	18:00
09b625ac-acd4-4f41-9a15-3822b29a96ed	caf90a65-a287-474f-bc9b-c9da6ad8ab30	5	09:00	18:00
3e354fae-36ce-4ca0-ac95-d851e714c1b2	caf90a65-a287-474f-bc9b-c9da6ad8ab30	6	10:00	15:00
6f7b69d2-8cf9-4bfb-9e65-45a61111a195	8dba2e99-0778-48a4-b243-ea784844fe52	1	10:00	20:00
e8c654ec-9b9e-4ce8-b7fd-529280ea06f1	8dba2e99-0778-48a4-b243-ea784844fe52	2	10:00	20:00
8ffb0024-158c-4994-b0a6-a643b22e00f7	8dba2e99-0778-48a4-b243-ea784844fe52	3	10:00	20:00
cf132e43-201d-4959-a8fb-35952761fdd6	8dba2e99-0778-48a4-b243-ea784844fe52	4	10:00	20:00
e0def392-f4d7-4ba0-8da6-9d8fcd9b8cda	8dba2e99-0778-48a4-b243-ea784844fe52	5	10:00	20:00
51c18ee1-c18e-465f-bf3a-5944f96ac9b5	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	1	09:00	18:00
f2287206-683c-40ff-8de1-766aee6f15cf	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	2	09:00	18:00
64a1bc94-8aa9-43c0-a148-a8002951f908	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	3	09:00	18:00
f71f600d-3d87-4c4d-b827-5ef2884c4dc6	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	4	09:00	18:00
f828780f-19b5-4e00-a52a-dc50bf36b040	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	5	09:00	18:00
13644668-61af-4c4a-9e39-79d4878e0f26	05886b1c-f0b5-4faf-a82e-464e5bb7ec9b	6	10:00	15:00
d5b42b8a-f4c7-4447-8985-cd72113c635c	8dba2e99-0778-48a4-b243-ea784844fe52	6	10:00	20:00
aa15419d-9bab-493c-8ae8-f29df7e5a2f1	97fdb979-27db-4561-90ec-4b9deb66dfbe	1	09:00	19:00
58a3d806-56b2-495a-8bb1-1978e8943c75	97fdb979-27db-4561-90ec-4b9deb66dfbe	2	09:00	19:00
60582be6-0d00-4b75-aa14-139ff7943f5a	97fdb979-27db-4561-90ec-4b9deb66dfbe	3	09:00	19:00
b15a0a6f-e66e-4767-a316-9a7350fbd91a	97fdb979-27db-4561-90ec-4b9deb66dfbe	4	09:00	19:00
388a5460-02eb-43da-bd79-db53aaa29981	97fdb979-27db-4561-90ec-4b9deb66dfbe	5	09:00	19:00
bb68c055-aafd-4366-993b-b733f829fef3	97fdb979-27db-4561-90ec-4b9deb66dfbe	6	09:00	19:00
d2cfed01-f890-405b-a7cd-8ca8d91e6250	2d8f2756-6958-4197-8b07-1238d0005781	1	09:00	18:00
70458ffa-aba8-4b98-b7ca-0e43411679af	2d8f2756-6958-4197-8b07-1238d0005781	2	09:00	18:00
8c3322f8-8fce-4824-8217-45575c6de1c4	2d8f2756-6958-4197-8b07-1238d0005781	3	09:00	18:00
875549c2-9c43-4cfe-b1c3-b53b89955e5e	2d8f2756-6958-4197-8b07-1238d0005781	4	09:00	18:00
f5b08802-fdc1-4472-bf06-a8dc85e2f7fc	2d8f2756-6958-4197-8b07-1238d0005781	5	09:00	18:00
6b17bc3a-d506-4f72-ac50-3f20809b1677	2d8f2756-6958-4197-8b07-1238d0005781	6	10:00	15:00
80a1847a-528e-4b1f-ab30-557c2e512a4c	609308e0-556b-41e1-8b39-6a719c0dc6e9	1	09:00	18:00
e936976a-c51c-4c34-8dc5-831160d4dbd5	609308e0-556b-41e1-8b39-6a719c0dc6e9	2	09:00	18:00
a770ec1b-eefb-4913-83d0-55dd861b0099	609308e0-556b-41e1-8b39-6a719c0dc6e9	3	09:00	24:00
689960e5-58ce-4513-a420-19f451d931a2	609308e0-556b-41e1-8b39-6a719c0dc6e9	4	09:00	18:00
edcf8c5b-b0a2-498e-8b8d-18337ad476e8	609308e0-556b-41e1-8b39-6a719c0dc6e9	5	09:00	18:00
ec6dcb02-d073-4598-9ea2-fb30f541ba29	609308e0-556b-41e1-8b39-6a719c0dc6e9	6	10:00	15:00
\.


--
-- Name: app_meta app_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.app_meta
    ADD CONSTRAINT app_meta_pkey PRIMARY KEY (key);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: client_batches client_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.client_batches
    ADD CONSTRAINT client_batches_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: clients clients_telegram_user_id_trainer_id_key; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_telegram_user_id_trainer_id_key UNIQUE (telegram_user_id, specialist_id);


--
-- Name: dashboard_audit_log dashboard_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.dashboard_audit_log
    ADD CONSTRAINT dashboard_audit_log_pkey PRIMARY KEY (id);


--
-- Name: days_off days_off_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.days_off
    ADD CONSTRAINT days_off_pkey PRIMARY KEY (id);


--
-- Name: days_off days_off_trainer_id_date_key; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.days_off
    ADD CONSTRAINT days_off_trainer_id_date_key UNIQUE (specialist_id, date);


--
-- Name: master_users master_users_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.master_users
    ADD CONSTRAINT master_users_pkey PRIMARY KEY (telegram_user_id);


--
-- Name: promo_codes promo_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_code_key UNIQUE (code);


--
-- Name: promo_codes promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: promo_redemptions promo_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.promo_redemptions
    ADD CONSTRAINT promo_redemptions_pkey PRIMARY KEY (id);


--
-- Name: recurring_schedules recurring_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.recurring_schedules
    ADD CONSTRAINT recurring_schedules_pkey PRIMARY KEY (id);


--
-- Name: session_types session_types_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.session_types
    ADD CONSTRAINT session_types_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: support_threads support_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.support_threads
    ADD CONSTRAINT support_threads_pkey PRIMARY KEY (id);


--
-- Name: support_threads support_threads_telegram_user_id_key; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.support_threads
    ADD CONSTRAINT support_threads_telegram_user_id_key UNIQUE (telegram_user_id);


--
-- Name: specialists trainers_bot_token_key; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.specialists
    ADD CONSTRAINT trainers_bot_token_key UNIQUE (bot_token);


--
-- Name: trainers trainers_bot_token_key1; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.trainers
    ADD CONSTRAINT trainers_bot_token_key1 UNIQUE (bot_token);


--
-- Name: specialists trainers_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.specialists
    ADD CONSTRAINT trainers_pkey PRIMARY KEY (id);


--
-- Name: trainers trainers_pkey1; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.trainers
    ADD CONSTRAINT trainers_pkey1 PRIMARY KEY (id);


--
-- Name: specialists trainers_telegram_user_id_key; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.specialists
    ADD CONSTRAINT trainers_telegram_user_id_key UNIQUE (telegram_user_id);


--
-- Name: trainers trainers_telegram_user_id_key1; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.trainers
    ADD CONSTRAINT trainers_telegram_user_id_key1 UNIQUE (telegram_user_id);


--
-- Name: specialists trainers_webhook_secret_key; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.specialists
    ADD CONSTRAINT trainers_webhook_secret_key UNIQUE (webhook_secret);


--
-- Name: trainers trainers_webhook_secret_key1; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.trainers
    ADD CONSTRAINT trainers_webhook_secret_key1 UNIQUE (webhook_secret);


--
-- Name: waitlist waitlist_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.waitlist
    ADD CONSTRAINT waitlist_pkey PRIMARY KEY (id);


--
-- Name: working_hours working_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.working_hours
    ADD CONSTRAINT working_hours_pkey PRIMARY KEY (id);


--
-- Name: idx_bookings_client_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_bookings_client_id ON public.bookings USING btree (client_id);


--
-- Name: idx_bookings_client_status_starts_at; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_bookings_client_status_starts_at ON public.bookings USING btree (client_id, status, starts_at);


--
-- Name: idx_bookings_recurring_status_starts_at; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_bookings_recurring_status_starts_at ON public.bookings USING btree (recurring_schedule_id, status, starts_at);


--
-- Name: idx_bookings_specialist_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_bookings_specialist_id ON public.bookings USING btree (specialist_id);


--
-- Name: idx_bookings_specialist_status_starts_at; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_bookings_specialist_status_starts_at ON public.bookings USING btree (specialist_id, status, starts_at);


--
-- Name: idx_bookings_starts_at; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_bookings_starts_at ON public.bookings USING btree (starts_at);


--
-- Name: idx_bookings_status; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_bookings_status ON public.bookings USING btree (status);


--
-- Name: idx_client_batches_client_service_status; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_client_batches_client_service_status ON public.client_batches USING btree (client_id, service_id, status, created_at);


--
-- Name: idx_client_batches_specialist_client; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_client_batches_specialist_client ON public.client_batches USING btree (specialist_id, client_id);


--
-- Name: idx_clients_specialist_name; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_clients_specialist_name ON public.clients USING btree (specialist_id, name);


--
-- Name: idx_dashboard_audit_created_at; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_dashboard_audit_created_at ON public.dashboard_audit_log USING btree (created_at DESC);


--
-- Name: idx_dashboard_audit_specialist_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_dashboard_audit_specialist_id ON public.dashboard_audit_log USING btree (specialist_id);


--
-- Name: idx_days_off_date; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_days_off_date ON public.days_off USING btree (date);


--
-- Name: idx_days_off_specialist_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_days_off_specialist_id ON public.days_off USING btree (specialist_id);


--
-- Name: idx_promo_codes_code; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_promo_codes_code ON public.promo_codes USING btree (code);


--
-- Name: idx_promo_redemptions_code_specialist; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE UNIQUE INDEX idx_promo_redemptions_code_specialist ON public.promo_redemptions USING btree (promo_code_id, specialist_id);


--
-- Name: idx_promo_redemptions_specialist; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_promo_redemptions_specialist ON public.promo_redemptions USING btree (specialist_id);


--
-- Name: idx_recurring_client_created_at; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_recurring_client_created_at ON public.recurring_schedules USING btree (client_id, created_at);


--
-- Name: idx_recurring_client_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_recurring_client_id ON public.recurring_schedules USING btree (client_id);


--
-- Name: idx_recurring_specialist_created_at; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_recurring_specialist_created_at ON public.recurring_schedules USING btree (specialist_id, created_at);


--
-- Name: idx_recurring_specialist_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_recurring_specialist_id ON public.recurring_schedules USING btree (specialist_id);


--
-- Name: idx_recurring_status; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_recurring_status ON public.recurring_schedules USING btree (status);


--
-- Name: idx_recurring_status_day_of_week_time; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_recurring_status_day_of_week_time ON public.recurring_schedules USING btree (status, day_of_week, "time");


--
-- Name: idx_session_types_specialist_active_type; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_session_types_specialist_active_type ON public.session_types USING btree (specialist_id, is_active, type);


--
-- Name: idx_specialists_bot_token_hash; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE UNIQUE INDEX idx_specialists_bot_token_hash ON public.specialists USING btree (bot_token_hash);


--
-- Name: idx_specialists_referral_code; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE UNIQUE INDEX idx_specialists_referral_code ON public.specialists USING btree (referral_code) WHERE ((referral_code IS NOT NULL) AND (referral_code <> ''::text));


--
-- Name: idx_subscription_payments_specialist_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_subscription_payments_specialist_id ON public.subscription_payments USING btree (specialist_id);


--
-- Name: idx_subscription_payments_yookassa_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_subscription_payments_yookassa_id ON public.subscription_payments USING btree (yookassa_payment_id);


--
-- Name: idx_support_threads_topic_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_support_threads_topic_id ON public.support_threads USING btree (topic_id);


--
-- Name: idx_waitlist_client_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_waitlist_client_id ON public.waitlist USING btree (client_id);


--
-- Name: idx_waitlist_specialist_id; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_waitlist_specialist_id ON public.waitlist USING btree (specialist_id);


--
-- Name: idx_waitlist_status; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_waitlist_status ON public.waitlist USING btree (status);


--
-- Name: idx_working_hours_specialist_day_start; Type: INDEX; Schema: public; Owner: scheduler
--

CREATE INDEX idx_working_hours_specialist_day_start ON public.working_hours USING btree (specialist_id, day_of_week, start_time);


--
-- Name: bookings bookings_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: bookings bookings_session_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_session_type_id_fkey FOREIGN KEY (session_type_id) REFERENCES public.session_types(id);


--
-- Name: bookings bookings_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_trainer_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: client_batches client_batches_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.client_batches
    ADD CONSTRAINT client_batches_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_batches client_batches_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.client_batches
    ADD CONSTRAINT client_batches_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.session_types(id);


--
-- Name: client_batches client_batches_specialist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.client_batches
    ADD CONSTRAINT client_batches_specialist_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: clients clients_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_trainer_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: days_off days_off_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.days_off
    ADD CONSTRAINT days_off_trainer_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: recurring_schedules recurring_schedules_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.recurring_schedules
    ADD CONSTRAINT recurring_schedules_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: recurring_schedules recurring_schedules_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.recurring_schedules
    ADD CONSTRAINT recurring_schedules_trainer_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: session_types session_types_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.session_types
    ADD CONSTRAINT session_types_trainer_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: subscription_payments subscription_payments_specialist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_specialist_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: waitlist waitlist_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.waitlist
    ADD CONSTRAINT waitlist_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: waitlist waitlist_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.waitlist
    ADD CONSTRAINT waitlist_trainer_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: working_hours working_hours_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: scheduler
--

ALTER TABLE ONLY public.working_hours
    ADD CONSTRAINT working_hours_trainer_id_fkey FOREIGN KEY (specialist_id) REFERENCES public.specialists(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: scheduler
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict eDPdhCP2Wu0g1yiy1xhLW8DJQjnYa6s2AGHqnbwm84UdZ3O21tT7pf2sxbtfHid

